-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : lun. 29 nov. 2021 à 15:06
-- Version du serveur : 10.4.20-MariaDB
-- Version de PHP : 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `story_book`
--

-- --------------------------------------------------------

--
-- Structure de la table `age`
--

CREATE TABLE `age` (
  `id_limit_age` int(11) NOT NULL,
  `limit_age` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `age`
--

INSERT INTO `age` (`id_limit_age`, `limit_age`) VALUES
(1, '5+'),
(2, '7+'),
(3, '10+'),
(4, '12+'),
(5, '14+'),
(6, '16+'),
(7, '18+');

-- --------------------------------------------------------

--
-- Structure de la table `histoire`
--

CREATE TABLE `histoire` (
  `id` int(11) NOT NULL,
  `idu` int(11) NOT NULL,
  `id_type_histoire` varchar(255) NOT NULL,
  `id_limit_age` varchar(255) NOT NULL,
  `titre` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `photo` text NOT NULL,
  `text_histoire` longtext NOT NULL,
  `date_pub` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `histoire`
--

INSERT INTO `histoire` (`id`, `idu`, `id_type_histoire`, `id_limit_age`, `titre`, `description`, `photo`, `text_histoire`, `date_pub`) VALUES
(1, 1, '3', '4', 'L\'histoire du chien', 'Ce fût son premier jour....', '../Uploads/1637574163.jpg', '<p style=\"box-sizing: inherit; outline: 0px; margin-bottom: 0px; padding-right: 1em; padding-bottom: 1em; padding-left: 1em; font-size: 1.2em; line-height: 1.4; color: rgb(51, 51, 51); font-family: Catamaran, sans-serif;\">On en a beaucoup dit sur&nbsp;<strong style=\"box-sizing: inherit; outline: 0px;\">l\'histoire, l\'origine et l\'évolution du chien.&nbsp;</strong>Il y a de très nombreuses théories sur le développement du chien en tant que meilleur ami de l\'homme, certaines affirment que les chiens sont des loups domestiqués qui ont évolué, alors que d\'autres soutiennent dur comme fer que, bien qu\'ils forment la famille des canidés, le loup et le chien ont des origines différentes.</p><p style=\"box-sizing: inherit; outline: 0px; margin-bottom: 0px; padding-right: 1em; padding-bottom: 1em; padding-left: 1em; font-size: 1.2em; line-height: 1.4; color: rgb(51, 51, 51); font-family: Catamaran, sans-serif;\">De plus, à quoi est dû l\'incroyable variété des races de chiens qui existent ? Comment est-ce qu\'ils ont pu développer des caractéristiques si différentes en appartenant à la même espèce ? Dans cet article&nbsp;<b style=\"box-sizing: inherit; outline: 0px;\">Histoire du chien&nbsp;</b>de PlanèteAnimal, on a décidé de répondre à ces questions, ainsi qu\'à d\'autres, dans ce nouvel article qui traite de&nbsp;<strong style=\"box-sizing: inherit; outline: 0px;\">l\'histoire, l\'origine et de l\'évolution du chien</strong>.</p>', '2021-11-22 10:42:42'),
(2, 2, '5', '5', 'Mon Premier voyage en train', 'Ce fût un moment magique, lorsque nous sommes arrivés à la gare pour les tickets...', '../Uploads/1637574556.jpg', '<p style=\"margin-bottom: 10px; color: rgb(51, 51, 51); font-family: \" source=\"\" serif=\"\" pro\",=\"\" \"times=\"\" new=\"\" roman\",=\"\" times,=\"\" serif;=\"\" font-size:=\"\" 18px;=\"\" text-align:=\"\" justify;\"=\"\">Les fils du Roi des Français Louis-Philippe, le Duc de Nemours et le Duc de Montpensier, vont, avec bien d’autres personnalités, prendre l’un des trois trains qui, pour la première fois en ce jour, vont relier deux capitales européennes: Paris et Bruxelles.</p><p style=\"margin-bottom: 10px; color: rgb(51, 51, 51); font-family: \" source=\"\" serif=\"\" pro\",=\"\" \"times=\"\" new=\"\" roman\",=\"\" times,=\"\" serif;=\"\" font-size:=\"\" 18px;=\"\" text-align:=\"\" justify;\"=\"\"><span style=\"font-size: 1rem;\">Alors bien sur, depuis 1835 et le premier voyage entre Malines et Bruxelles, du chemin a été fait, et à grand pas. La gare de Lille a même déjà été reliée au chemin de fer Belge, avant de l’être avec le réseau Français... Car, du coté Français, on tarde... L’argent manque pour construire les lignes. Et c’est finalement le Baron James de Rothschild qui va financer la construction de la ligne entre Paris et Lille.</span></p><p style=\"margin-bottom: 10px; color: rgb(51, 51, 51); font-family: \" source=\"\" serif=\"\" pro\",=\"\" \"times=\"\" new=\"\" roman\",=\"\" times,=\"\" serif;=\"\" font-size:=\"\" 18px;=\"\" text-align:=\"\" justify;\"=\"\">&nbsp;</p><p style=\"margin-bottom: 10px; color: rgb(51, 51, 51); font-family: \" source=\"\" serif=\"\" pro\",=\"\" \"times=\"\" new=\"\" roman\",=\"\" times,=\"\" serif;=\"\" font-size:=\"\" 18px;=\"\" text-align:=\"\" justify;\"=\"\">Le 13, c’est donc l’effervescence... La ligne est inaugurée en grande pompe... Festivités en tout genre vont se succéder tout au long du voyage, le premier jour entre Paris et Lille, le second entre Lille et Bruxelles.</p><p style=\"margin-bottom: 10px; color: rgb(51, 51, 51); font-family: \" source=\"\" serif=\"\" pro\",=\"\" \"times=\"\" new=\"\" roman\",=\"\" times,=\"\" serif;=\"\" font-size:=\"\" 18px;=\"\" text-align:=\"\" justify;\"=\"\">&nbsp;</p><p style=\"margin-bottom: 10px; color: rgb(51, 51, 51); font-family: \" source=\"\" serif=\"\" pro\",=\"\" \"times=\"\" new=\"\" roman\",=\"\" times,=\"\" serif;=\"\" font-size:=\"\" 18px;=\"\" text-align:=\"\" justify;\"=\"\">Mais, si le voyage est un franc succès, lançant le continent européen dans l’épopée du rail, très vite, la presse de l’époque se montre très critique à l’égard de cette opération... Le départ est un dimanche, jour de la Fête Dieu.. il n’y avait bien qu’un financier juif pour imaginer cela ! Scandale ! Il est impossible d’aller à la messe obligatoire en ce jour! Et puis, après tout, il n’y a pas si longtemps, en 1815, la majorité de la Belgique était encore des départements français..... Oui la fille du Roi Louis Philippe est devenue la première Reine des Belges... Mais bon... Et puis tout cela est fait avec de l’argent privé, ce qui a suscité bien des débats en France....</p><p style=\"margin-bottom: 10px; color: rgb(51, 51, 51); font-family: \" source=\"\" serif=\"\" pro\",=\"\" \"times=\"\" new=\"\" roman\",=\"\" times,=\"\" serif;=\"\" font-size:=\"\" 18px;=\"\" text-align:=\"\" justify;\"=\"\">Et puis le chemin de fer, tout cela nous viens de Grande Bretagne... On a vu des ingénieurs anglais partout ces derniers temps.... Les ennemis de 1815.... Et, en plus, tous les ouvriers qui ont construit la ligne sont les oubliés de la fête...</p><p style=\"margin-bottom: 10px; color: rgb(51, 51, 51); font-family: \" source=\"\" serif=\"\" pro\",=\"\" \"times=\"\" new=\"\" roman\",=\"\" times,=\"\" serif;=\"\" font-size:=\"\" 18px;=\"\" text-align:=\"\" justify;\"=\"\">Mais bon.. Voilà. C’est fait... Paris et Bruxelles sont reliés en chemin de fer... Et, si le premier voyage a duré deux jours, très vite, il va s’effectuer plus vite.... et cela va s’accélérer, jusqu’à, il y a 20 ans, la première ligne Thalys, qui va faire le trajet en... une heure 20....<strong style=\"font-size: 1rem; font-weight: bold;\">Alors, pour fêter ce premier voyage, Stéphane DISIERE, responsable du patrimoine historique de la SNCB, et Dominick MARTINOT-LAGARDE ont pris le train, ce train à grande vitesse, qui part de la Gare du Nord et rejoint Bruxelles. Et ils ont refait le voyage.... dans bien d’autres conditions que lors de ces journées des 14 et 15 juin 1846..... pour vous le faire revivre...</strong></p><p style=\"margin-bottom: 10px; color: rgb(51, 51, 51); font-family: \" source=\"\" serif=\"\" pro\",=\"\" \"times=\"\" new=\"\" roman\",=\"\" times,=\"\" serif;=\"\" font-size:=\"\" 18px;=\"\" text-align:=\"\" justify;\"=\"\">&nbsp;</p>', '2021-11-22 10:49:16'),
(3, 3, '5', '4', 'Les peuples bizarres', 'Wigmen Huli...', '../Uploads/1637750708.jpg', '<p style=\"margin-bottom: 20px; color: rgb(100, 100, 100); font-family: Roboto, sans-serif; font-size: 17px;\">Les chapeaux portés par cette singulière tribu sont faits avec les cheveux de leurs pairs qu’ils combinent avec de la peinture jaune et une hache pourvue de griffes pour effrayer leurs adversaires. Cette coutume est aussi bizarre qu’impressionnante. Rien ne se perd chez les Wigmen Huli et surtout pas les cheveux apparemment !</p><p style=\"margin-bottom: 20px; color: rgb(100, 100, 100); font-family: Roboto, sans-serif; font-size: 17px;\">Ce peuple habite les montagnes du centre de la Papouasie – Nouvelle-Guinée, une île au Nord de l’Australie. Ils vivent notamment de la culture de la patate douce, &nbsp;dont ils maîtrisent très bien les techniques, ce qui leur permet d’avoir un niveau de rendement important. Ils élèvent également des cochons, qui leurs servent avant tout de monnaie d’échange. Une particularité de cette tribu bizarre, du moins quand on considère la différence bizarre, est qu’ils ne possèdent pas de propriété collective et organisent peu d’actions communes, au contraire ils tendent à s’affronter les uns avec les autres.</p>', '2021-11-24 11:45:08'),
(4, 3, '5', '4', 'Les peuples étranges', 'Korowai', '../Uploads/1637750860.jpg', '<p><span style=\"color: rgb(100, 100, 100); font-family: Roboto, sans-serif; font-size: 17px;\">Ceux qui sont vraiment effrayants sont les&nbsp;</span><em style=\"color: rgb(100, 100, 100); font-family: Roboto, sans-serif; font-size: 17px;\">Korowai</em><span style=\"color: rgb(100, 100, 100); font-family: Roboto, sans-serif; font-size: 17px;\">, aussi appelés&nbsp;</span><em style=\"color: rgb(100, 100, 100); font-family: Roboto, sans-serif; font-size: 17px;\">Kolufaup :</em><span style=\"color: rgb(100, 100, 100); font-family: Roboto, sans-serif; font-size: 17px;\">&nbsp;une tribu cannibale qui mange tous ceux qui font du mal à l’un de leurs membres. Cependant, il semble, selon les anthropologues qu’ils ne pratiquent plus l’anthropophagie depuis le début du XXème siècle. En 2010, on recensait 2 868 korowai. Ils sont également connus comme vivant à la cime des arbres, une anecdote peu impressionnante comparée à leur pratique cannibalesque passée. En effet, ils construisent leurs maisons avec du bois, du bambou et des feuilles perchées dans les arbres. Cela leur permet d’avoir une visibilité importante en cas d’attaque et également de se protéger des parasites, moustiques, serpents et autres animaux pouvant représenter une menace.</span><br></p>', '2021-11-24 11:47:39'),
(5, 2, '5', '5', 'Des peuples étranges...', 'Mursi', '../Uploads/1637750982.jpg', '<p style=\"margin-bottom: 20px; color: rgb(100, 100, 100); font-family: Roboto, sans-serif; font-size: 17px;\">Les pratiques de la tribu Mursi, originaire de la vallée de l’Omo en Ethiopie pourront en surprendre quelques-uns. En effet, les membres de cette tribu ont les lèvres les plus surprenantes de la planète, du moins de notre point de vue. Les femmes Mursi portent depuis leur plus jeune âge une “petite” plaque dans la lèvre inférieure que l’on appelle un «&nbsp;plateau labial&nbsp;» et qui symbolise la beauté de la femme mais surtout la maturité sexuelle.</p><p style=\"margin-bottom: 20px; color: rgb(100, 100, 100); font-family: Roboto, sans-serif; font-size: 17px;\">Certains touristes sont d’ailleurs prêts à payer pour obtenir une photographie d’une de ces femmes…On reste perplexe.</p>', '2021-11-24 11:49:42'),
(6, 2, '5', '5', 'peuples étranges', 'Paduang....', '../Uploads/1637751052.jpg', '<p style=\"margin-bottom: 20px; color: rgb(100, 100, 100); font-family: Roboto, sans-serif; font-size: 17px;\">La tribu Paduang est originaire du Myanmar en Birmanie, mais suite à un conflit avec l’armée birmane, nombres d’entre eux ont fui pour la Thaïlande.</p><p style=\"margin-bottom: 20px; color: rgb(100, 100, 100); font-family: Roboto, sans-serif; font-size: 17px;\">La particularité de cette tribu est que les femmes sont appelées femmes “girafes”. En effet, elles portent durant toute leur vie de nombreux anneaux en laiton autour du cou qu’elles ne retirent jamais. Ces colliers sont en vérité une spirale qui est changée avec l’âge. Ces colliers-spirale donnent l’impression que ces femmes ont un plus long cou mais en réalité c’est leur cage thoracique qui est comprimée.</p><p style=\"margin-bottom: 20px; color: rgb(100, 100, 100); font-family: Roboto, sans-serif; font-size: 17px;\">Malgré leurs recherches, les anthropologues ayant travaillés sur la question ne s’accordent pas quant à la signification de cette coutume. Elle reste donc un mystère mais un caractéristique très forte dans leur identité culturelle.</p>', '2021-11-24 11:50:52'),
(7, 3, '5', '5', 'des peuples étranges', 'Asaro', '../Uploads/1637751190.jpg', '<p><span style=\"color: rgb(100, 100, 100); font-family: Roboto, sans-serif; font-size: 17px;\">La tribu des Asaro, aussi connue sous le nom de «&nbsp;hommes de boue&nbsp;», fête chaque année la victoire d’une bataille que la tribu a gagnée contre une tribu ennemie le siècle dernier. Plusieurs légendes expliquent la particularité de cette bataille. En effet, la plus répandue raconte que les hommes de la tribu d’Asaro auraient un jour &nbsp;découvert leur village pillé et leurs femmes enlevées par un clan voisin. Bien qu’en minorité, ils décidèrent de tenter d’aller sauver leurs femmes. Mais avant d’atteindre le village de ce clan, ils se seraient perdus dans la jungle. Pris au piège dans un marais boueux, ils auraient perdu leurs armes. Couverts de boue blanche séchée sur le corps, sans renoncer, ils arrivèrent finalement au village de l’ennemi qui prit peur en voyant ces ombres blanches. Ils récupèrent ainsi leurs femmes, forts d’une nouvelle «&nbsp;armure&nbsp;».</span><br></p>', '2021-11-24 11:53:09');

-- --------------------------------------------------------

--
-- Structure de la table `type`
--

CREATE TABLE `type` (
  `id_type_histoire` int(11) NOT NULL,
  `type_histoire` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `type`
--

INSERT INTO `type` (`id_type_histoire`, `type_histoire`) VALUES
(1, 'BD / Roman graphique'),
(2, 'Poésie'),
(3, 'Histoire ados'),
(4, 'Histoire policière'),
(5, 'Histoire aventure'),
(6, 'Romance'),
(7, 'Science fiction'),
(8, 'fantastique');

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

CREATE TABLE `utilisateur` (
  `id` int(11) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `genre` varchar(255) NOT NULL,
  `habitation` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `photo` text NOT NULL,
  `passe` varchar(255) NOT NULL,
  `statut` enum('0','1') NOT NULL DEFAULT '0',
  `type_ut` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `utilisateur`
--

INSERT INTO `utilisateur` (`id`, `nom`, `genre`, `habitation`, `email`, `photo`, `passe`, `statut`, `type_ut`) VALUES
(2, 'Jonas', 'Homme', 'Marcory, Civ', 'Jojo78@gmail.com', '../image/1637573250.jpg', '7ca0387fb29389a4a5ddb3c75c23d9dd', '0', ''),
(3, 'Gisèle', 'Femme', 'Marcory, CIV', 'Gis78@gmail.com', '../image/1637750536.png', '7ca0387fb29389a4a5ddb3c75c23d9dd', '0', '');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `age`
--
ALTER TABLE `age`
  ADD PRIMARY KEY (`id_limit_age`);

--
-- Index pour la table `histoire`
--
ALTER TABLE `histoire`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `type`
--
ALTER TABLE `type`
  ADD PRIMARY KEY (`id_type_histoire`);

--
-- Index pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `age`
--
ALTER TABLE `age`
  MODIFY `id_limit_age` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT pour la table `histoire`
--
ALTER TABLE `histoire`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT pour la table `type`
--
ALTER TABLE `type`
  MODIFY `id_type_histoire` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
