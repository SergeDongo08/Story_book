<?php

//information sur celui qui fait la publication
include 'postinfo.php';

//affichage des histoire de la base de données
include '../moncompte/ok.php'



?>

