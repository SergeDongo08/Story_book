<?php
// Start the session
session_start();
include '../access/connexion.php';
include '../access/connexionpdo.php';
include '../access/session.php';

if(!isset($_GET['id']) || (int)($_GET['id']) < 0 ){
  header("Location:profil.php");
 }else{
   $q = $con -> query("SELECT * FROM histoire WHERE id = '{$_GET['id']}'")->fetch(PDO::FETCH_OBJ) ;
   if(!$q){
     header("Location:profil.php");
   }
 }
?>
<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">

    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
        integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous">
    </script>
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.js"></script>

    <title>Modifications</title>

    <!-- Bootstrap core CSS -->
    <link href="../bootstrap.css" rel="stylesheet">
    <link href="../summernote/summernote.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap');

    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: "Poppins", sans-serif;
    }

    *****************/ #searchbox {
        /*background: #d8d8d8;
/*border: 4px solid #e8e8e8;*/
        padding: 20px 10px;
        width: 250px;
    }

    input:focus::-webkit-input-placeholder {
        color: transparent;
    }



    input:focus:-moz-placeholder {
        color: transparent;
    }

    input:focus::-moz-placeholder {
        color: transparent;
    }

    #searchbox input {
        outline: none;
    }

    #searchbox input[type=text] {
        background: url(http://2.bp.blogspot.com/-xpzxYc77ack/VDpdOE5tzMI/AAAAAAAAAeQ/TyXhIfEIUy4/s1600/search-dark.png) no-repeat 10px 6px #fff;
        border-width: 1px;
        border-style: solid;
        border-color: #fff;
        font: bold 12px Arial, Helvetica, Sans-serif;
        color: #bebebe;
        width: 55%;
        padding: 8px 15px 8px 30px;
    }

    #button-submit {
        background: #3D3B3B;
        border-width: 0px;
        padding: 9px 0px;
        width: 23%;
        cursor: pointer;
        font: bold 12px Arial, Helvetica;
        color: #fff;
        text-shadow: 0 1px 0 #555;
    }

    #button-submit:hover {
        background: #4f5356;
    }

    #button-submit:active {
        background: #5b5d60;
        outline: none;
    }



    #button-submit::-moz-focus-inner {
        border: 0;
    }

    ******/ section {
        padding: 20px 100px;
    }

    .section-home {
        position: relative;
        min-height: 100vh;
        /* background: url(bg.jpg)no-repeat;*/
        background-size: cover;
        background-position: center;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .section-home:before {
        content: '';
        position: absolute;
        background: linear-gradient(to top, #23252B, transparent);
        width: 100%;
        height: 80px;
        bottom: 0;
    }

    .section-home h1 {
        color: #fff;
        font-size: 10vw;
        font-weight: 800;
        text-shadow: 0 5px 25px rgb(0 0 0 / 20%);
        opacity: 0.3;
    }

    .section-two {
        min-height: 100vh;
        background: #23252B;
    }

    .section-two h2 {
        color: #fff;
        font-size: 3em;
        font-weight: 700;
        margin: 30px 0;
    }

    .section-two p {
        color: #fff;
        font-size: 1em;
        margin: 30px 0;
    }

    header {
        z-index: 999;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        display: flex;
        justify-content: space-between;
        align-items: center;
        background: #23252B;
        box-shadow: 0 5px 25px rgb(0 0 0 / 20%);
        padding: 0 100px;
        transition: 0.6s;
    }

    header .logo {
        color: #fff;
        font-size: 1.8em;
        font-weight: 700;
        text-transform: uppercase;
        text-decoration: none;
        letter-spacing: 2px;
    }

    header .navigation {
        position: relative;
        line-height: 75px;
        transition: 0.6s;
        transition-property: line-height;
    }

    header.sticky .navigation {
        line-height: 60px;
    }

    header .navigation .menu {
        position: relative;
        display: flex;
        justify-content: center;
        list-style: none;
        user-select: none;
    }

    .menu-item>a {
        color: #fff;
        font-size: 1em;
        text-decoration: none;
        margin: 20px;
        padding: 25px 0;
    }

    .menu-item>a:hover {
        color: #469DFF;
        transition: 0.3s;
    }

    .menu-item .sub-menu {
        position: absolute;
        background: #23252B;
        top: 74px;
        line-height: 40px;
        list-style: none;
        border-radius: 0 0 8px 8px;
        box-shadow: 0 5px 25px rgb(0 0 0 / 20%);
        pointer-events: none;
        transform: translateY(20px);
        opacity: 0;
        transition: 0.3s;
        transition-property: transform, opacity;
    }

    header.sticky .menu-item .sub-menu {
        top: 60px;
    }

    .menu-item:hover .sub-menu {
        pointer-events: all;
        transform: translateY(0);
        opacity: 1;
    }

    .menu-item .sub-menu .sub-item {
        position: relative;
        padding: 7px 0;
        cursor: pointer;
        box-shadow: inset 0px -30px 5px -30px rgba(255, 255, 255, 0.2);
    }

    .menu-item .sub-menu .sub-item a {
        color: #fff;
        font-size: 1em;
        text-decoration: none;
        padding: 15px 30px;
    }

    .menu-item .sub-menu .sub-item:hover {
        background: #4080EF;
    }

    .menu-item .sub-menu .sub-item:last-child:hover {
        border-radius: 0 0 8px 8px;
    }

    .menu-btn {
        display: none;
    }

    @media (max-width: 1060px) {
        header .navigation .menu {
            position: fixed;
            display: block;
            background: #CC9DF5;
            min-width: 350px;
            height: 100vh;
            top: 0;
            right: -100%;
            padding: 90px 50px;
            visibility: hidden;
            overflow-y: auto;
            transition: 0.5s;
            transition-property: right, visibility;
        }

        header.sticky .navigation {
            line-height: 75px;
        }

        header .navigation .menu.active {
            right: 0;
            visibility: visible;
        }

        .menu-item {
            position: relative;
        }

        .menu-item .sub-menu {
            opacity: 1;
            position: relative;
            top: 0;
            transform: translateX(10px);
            background: rgba(255, 255, 255, 0.1);
            border-radius: 5px;
            overflow: hidden;
            display: none;
        }

        header.sticky .menu-item .sub-menu {
            top: 0;
        }

        .close-btn {
            position: absolute;
            /*background: url(close.png)no-repeat;*/
            width: 40px;
            height: 40px;
            background-size: 25px;
            background-position: center;
            top: 0;
            left: 0;
            margin: 25px;
            cursor: pointer;
        }

        .menu-btn {
            /*background: url(menu.png)no-repeat;*/
            width: 40px;
            height: 40px;
            background-size: 30px;
            background-position: center;
            cursor: pointer;
            display: block;
        }

        header {
            padding: 15px 20px;
        }

        header.sticky {
            padding: 10px 20px;
        }
    }
    </style>
</head>

<body>
    <?php

	 if(isset($_SESSION["id"])){ //verification si on a un get
	//verification si l'information get egale a l'id dans la session
	 	echo "mowwwdiaaa";
    
    ?>
    <header>
        <p style="color: white; "><img src="<?php echo $photo ;?>"
                style=" width: 40px; height: 40px; background: black; border-radius: 50%;"><br><?php echo $nom; ?></p>
        <div class="navigation">
            <ul class="menu">
                <div class="close-btn"></div>
                <li class="menu-item"><a href="profil.php">Mon profil</a></li>
                <li class="menu-item">
                    <a class="sub-btn" href="#">Menu <i class="fas fa-angle-down"></i></a>
                    <ul class="sub-menu">
                        <li class="sub-item"><a href="ecrire.php">Publier une histoire</a></li>
                        <li class="sub-item"><a href="admin.php">Mes histoires</a></li>
                        <li class="sub-item"><a href="#"></a></li>
                    </ul>
                </li>

                <!--<li class="menu-item"><a href="#">About</a></li>-->
                <li class="menu-item"><a href="logout.php">Déconnection</a></li>
            </ul>
        </div>
        <div class="menu-btn"></div>
    </header>
    <br>
    <br>
    <br>
    <br>
    <img src="../images/rière.png" style="width:35px;"><a href="admin.php">Retour</a>
    <br>

    <p style="text-align: center;"><?php echo'Modifier (*_*)';?></p>
    <hr>
    <div class="container">

        <form method="POST" action="" enctype="multipart/form-data">
            <main class="container">

                <div class="row">
                    <div class="starter-template  col-lg-12">
                        <h1 class="mt-5 text-center"></h1>

                        <div></br>
                            <input type="text" class="form-control" name="titre" value="<?php echo $q-> titre ;?>">
                        </div></br>
                        <div>

                            <input type="text" class="form-control" name="description"
                                value="<?php echo $q-> description ;?>">
                        </div></br>
                        <div class="mb-3">
                            <input type="file" class="form-control" id="photo" value="<?php echo $q-> photo ;?>"
                                name="photo">
                        </div><br>
                        <div class="form-group mb-3">
                            <textarea id="summernote" class="form-control"
                                name="text_histoire"><?php echo $q-> text_histoire ;?></textarea>
                        </div>
                        <br>
                        <br>
                        <div>
                            <label>Entrer votre mot de passe</label>
                            <input class="form-control" type="password" name="password"
                                placeholder="Entrer votre mot de passe">
                        </div>
                        <br>
                        <button type="submit" class="btn btn-primary" name="edit">Editer</button>
                        <button type="submit" class="btn btn-danger" name="supprimer">Supprimer</button>

                    </div>
                </div>
            </main><!-- /.container -->

            <!-- Bootstrap core JavaScript
    ================================================== -->

    </div> <!-- Placed at the end of the document so the pages load faster -->

    <div id="summernote"></div>
    <script>
    $('#summernote').summernote({
        placeholder: 'Entrez un texte!',
        tabsize: 2,
        height: 120,
        toolbar: [
            //   ['style', ['style']],
            ['font', ['bold', 'underline', 'clear']],
            ['color', ['color']],
            ['para', ['ul', 'ol', 'paragraph']],
            //   ['table', ['table']],
            //   ['insert', ['link', 'picture', 'video']],
            //   ['view', ['fullscreen', 'codeview', 'help']]
        ]
    });
    </script>

    <!-- <input type="hidden" name="content" id="content"> -->
    <!-- <button type="button" class="btn btn-primary" style="margin-top: 15px" name="submit">Enregistrer</button> -->



    </form>

    <?php 
       //edition
       if (isset($_POST['edit'])) {
           //collecte information

    $titre = addslashes($_POST['titre']);
    $description = addslashes($_POST['description']);
    $text_histoire = addslashes($_POST['text_histoire']);
    $password = md5(addslashes($_POST['password']));

    //mise a jour titre, description, text_histoire, photo, passe
if ($password == $passe){
    $sql = "UPDATE histoire SET titre='$titre',description='$description', text_histoire ='$text_histoire' WHERE id='$id'";
}else{
    $sql = "UPDATE histoire SET titre='$titre',description='$description', text_histoire ='$text_histoire' WHERE id='$id'";
}
    if (mysqli_query($conn, $sql)) {
        echo "Record updated successfully";
        echo '<script>window.location.replace("../moncompte/profil.php")</script>';
      } else {
        echo "Error updating record: " . mysqli_error($conn);
      }
      

       }

       //fin edition


/// delete
if (isset($_POST['supprimer'])) {
    $sql = "DELETE FROM histoire WHERE id='{$_GET['id']}'";

    if (mysqli_query($conn, $sql)) {
    echo "Record deleted successfully";
    echo '<script>window.location.replace("../moncompte/logout.php")</script>';
  	} else {
    echo "Error deleting record: " . mysqli_error($conn);
    }

}

?>


    </div>

    <?php
    //echo "Mow";
 }else{ 
  echo '<script>window.location.replace("../moncompte/profil.php")</script>';
 	 //header('Location: logout.php');
 	//echo "chien vert";
}


 mysqli_close($conn); //fermer la connexion

    ?>

</body>

</html>