<?php 


  $check = "SELECT * FROM histoire";
  $result = mysqli_query($conn, $check);
  $nombre = mysqli_num_rows($result);

 
  //Resultat par page
  $results_per_page = 6;

  //Nombre des pages
  $number_of_pages = ceil($nombre/$results_per_page);


  //déterminer sur quel numéro de page se trouve actuellement le visiteur
  if (!isset($_GET['page'])) {
    $page = 1;
  } else {
    $page = $_GET['page'];
  }

  //déterminer le numéro de départ sql LIMIT pour les résultats sur la page d'affichage
  $this_page_first_result = ($page-1)*$results_per_page;

  $sql='SELECT * FROM histoire LIMIT ' . $this_page_first_result . ',' .  $results_per_page;
  $result = mysqli_query($conn, $sql);

    if ($nombre > 0) {
        //aller à la page
        echo '<div class="row">';
        while ($row = mysqli_fetch_assoc($result)) {
          $idu = $row['idu'];
          $nomUtilisateur = "SELECT * FROM utilisateur WHERE id = '$idu'";
          $resultNom = mysqli_query($conn, $nomUtilisateur);
          $rowNom = mysqli_fetch_assoc($resultNom);

          if(!$rowNom){
            $rowNom = 'Aucun utilisateur trouvé';
          }elseif($row['idu'] ==  $id){
            $rowNom = 'Par vous' ;
          }else{
            $rowNom = $rowNom['nom'];
          }


          //Pour la limite de l'age
          $ida = $row['id_limit_age'];
          $limitage = "SELECT * FROM age WHERE id_limit_age = '$ida'";
          $resultage = mysqli_query($conn, $limitage);
          $rowage = mysqli_fetch_assoc($resultage);

            // et le type d'histoire
            $idt = $row['id_type_histoire'];
            $typehist = "SELECT * FROM type WHERE id_type_histoire = '$idt'";
            $resultty = mysqli_query($conn, $typehist);
            $rowtype = mysqli_fetch_assoc($resultty);
        

          $affich = '<div class="col"><div class="card" style="width: 18rem;">

          <h5 class="card-title">Titre: '.$row["titre"].'</h5>
            <div class="card-text">Auteur: '.$rowNom.'</div>
            <div class="card-text" style="color: #240A04;">'.$rowage['limit_age'].'</div>
            <div class="card-text" style="color: #075C30;">'.$rowtype['type_histoire'].'</div>
            <br>

            <a href="../moncompte/lire.php?id='. $row["id"].'"><img src="'.$row["photo"].'" class="card-img-top"></a>
          <div class="card-body">
              <div class="card-text">'.$row["description"].'</div><br>
            <div class="card-text"> Publié le '.strftime("%d %b %Y à %R", strtotime($row["date_pub"])).'</div>
            <br>
              <a href="../moncompte/lire.php?id='.$row["id"].'" class="btn" name="lire" id="lire">Lire plus</a>
          </div>
          </div>
          </div>';
          echo $affich;

        }
        echo '</div>';
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
    echo "<br>";
    echo "<br>";
    echo "<br>";
    echo "<center>";
    
  // Le nombre de page s'incrémente au fur et à mesure
  for ($page=1;$page<=$number_of_pages;$page++) {
    echo '<a href="profil.php?page=' . $page . '">' . $page . '</a>
    ';
  }
  echo "</center>";
    
?>