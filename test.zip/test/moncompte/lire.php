<?php
session_start();
ob_start();
//Vérrification de connection
include '../access/connexion.php';
include '../access/connexionpdo.php';
include '../access/session.php';


if(!isset($_GET['id']) || (int)($_GET['id']) < 0 ){
   header("Location:profil.php");
  }else{
    $q = $con -> query("SELECT * FROM histoire WHERE id = '{$_GET['id']}'")->fetch(PDO::FETCH_OBJ) ;
    if(!$q){
      header("Location:profil.php");
    }
  }

?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>M.S.B</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" charset="utf-8"></script>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap');

    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: "Poppins", sans-serif;
    }

    *****************/ #searchbox {
        /*background: #d8d8d8;
/*border: 4px solid #e8e8e8;*/
        padding: 20px 10px;
        width: 250px;
    }

    input:focus::-webkit-input-placeholder {
        color: transparent;
    }



    input:focus:-moz-placeholder {
        color: transparent;
    }

    input:focus::-moz-placeholder {
        color: transparent;
    }

    #searchbox input {
        outline: none;
    }

    #searchbox input[type=text] {
        background: url(http://2.bp.blogspot.com/-xpzxYc77ack/VDpdOE5tzMI/AAAAAAAAAeQ/TyXhIfEIUy4/s1600/search-dark.png) no-repeat 10px 6px #fff;
        border-width: 1px;
        border-style: solid;
        border-color: #fff;
        font: bold 12px Arial, Helvetica, Sans-serif;
        color: #bebebe;
        width: 55%;
        padding: 8px 15px 8px 30px;
    }

    #button-submit {
        background: #3D3B3B;
        border-width: 0px;
        padding: 9px 0px;
        width: 23%;
        cursor: pointer;
        font: bold 12px Arial, Helvetica;
        color: #fff;
        text-shadow: 0 1px 0 #555;
    }

    #button-submit:hover {
        background: #4f5356;
    }

    #button-submit:active {
        background: #5b5d60;
        outline: none;
    }



    #button-submit::-moz-focus-inner {
        border: 0;
    }

    ******/ section {
        padding: 20px 100px;
    }

    .section-home {
        position: relative;
        min-height: 100vh;
        /*background: url(bg.jpg)no-repeat;*/
        background-size: cover;
        background-position: center;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .section-home:before {
        content: '';
        position: absolute;
        background: linear-gradient(to top, #23252B, transparent);
        width: 100%;
        height: 80px;
        bottom: 0;
    }

    .section-home h1 {
        color: #fff;
        font-size: 10vw;
        font-weight: 800;
        text-shadow: 0 5px 25px rgb(0 0 0 / 20%);
        opacity: 0.3;
    }

    .section-two {
        min-height: 100vh;
        background: #23252B;
    }

    .section-two h2 {
        color: #fff;
        font-size: 3em;
        font-weight: 700;
        margin: 30px 0;
    }

    .section-two p {
        color: #fff;
        font-size: 1em;
        margin: 30px 0;
    }

    header {
        z-index: 999;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        display: flex;
        justify-content: space-between;
        align-items: center;
        background: #23252B;
        box-shadow: 0 5px 25px rgb(0 0 0 / 20%);
        padding: 0 100px;
        transition: 0.6s;
    }

    header .logo {
        color: #fff;
        font-size: 1.8em;
        font-weight: 700;
        text-transform: uppercase;
        text-decoration: none;
        letter-spacing: 2px;
    }

    header .navigation {
        position: relative;
        line-height: 75px;
        transition: 0.6s;
        transition-property: line-height;
    }

    header.sticky .navigation {
        line-height: 60px;
    }

    header .navigation .menu {
        position: relative;
        display: flex;
        justify-content: center;
        list-style: none;
        user-select: none;
    }

    .menu-item>a {
        color: #fff;
        font-size: 1em;
        text-decoration: none;
        margin: 20px;
        padding: 25px 0;
    }

    .menu-item>a:hover {
        color: #469DFF;
        transition: 0.3s;
    }

    .menu-item .sub-menu {
        position: absolute;
        background: #23252B;
        top: 74px;
        line-height: 40px;
        list-style: none;
        border-radius: 0 0 8px 8px;
        box-shadow: 0 5px 25px rgb(0 0 0 / 20%);
        pointer-events: none;
        transform: translateY(20px);
        opacity: 0;
        transition: 0.3s;
        transition-property: transform, opacity;
    }

    header.sticky .menu-item .sub-menu {
        top: 60px;
    }

    .menu-item:hover .sub-menu {
        pointer-events: all;
        transform: translateY(0);
        opacity: 1;
    }

    .menu-item .sub-menu .sub-item {
        position: relative;
        padding: 7px 0;
        cursor: pointer;
        box-shadow: inset 0px -30px 5px -30px rgba(255, 255, 255, 0.2);
    }

    .menu-item .sub-menu .sub-item a {
        color: #fff;
        font-size: 1em;
        text-decoration: none;
        padding: 15px 30px;
    }

    .menu-item .sub-menu .sub-item:hover {
        background: #4080EF;
    }

    .menu-item .sub-menu .sub-item:last-child:hover {
        border-radius: 0 0 8px 8px;
    }

    .menu-btn {
        display: none;
    }

    @media (max-width: 1060px) {
        header .navigation .menu {
            position: fixed;
            display: block;
            background: #CC9DF5;
            min-width: 350px;
            height: 100vh;
            top: 0;
            right: -100%;
            padding: 90px 50px;
            visibility: hidden;
            overflow-y: auto;
            transition: 0.5s;
            transition-property: right, visibility;
        }

        header.sticky .navigation {
            line-height: 75px;
        }

        header .navigation .menu.active {
            right: 0;
            visibility: visible;
        }

        .menu-item {
            position: relative;
        }

        .menu-item .sub-menu {
            opacity: 1;
            position: relative;
            top: 0;
            transform: translateX(10px);
            background: rgba(255, 255, 255, 0.1);
            border-radius: 5px;
            overflow: hidden;
            display: none;
        }

        header.sticky .menu-item .sub-menu {
            top: 0;
        }

        .menu-item:hover .sub-menu {
            transform: translateX(10px);
        }

        .menu-item .sub-menu .sub-item {
            box-shadow: none;
        }

        .menu-item .sub-menu .sub-item:hover {
            background: none;
        }

        .menu-item .sub-menu .sub-item a:hover {
            color: #4080EF;
            transition: 0.3s;
        }

        .close-btn {
            position: absolute;
            /*background: url(close.png)no-repeat;*/
            width: 40px;
            height: 40px;
            background-size: 25px;
            background-position: center;
            top: 0;
            left: 0;
            margin: 25px;
            cursor: pointer;
        }

        .menu-btn {
            /*background: url(menu.png)no-repeat;*/
            width: 40px;
            height: 40px;
            background-size: 30px;
            background-position: center;
            cursor: pointer;
            display: block;
        }

        header {
            padding: 15px 20px;
        }

        header.sticky {
            padding: 10px 20px;
        }
    }



    .card {
        box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
        max-width: 300px;
        margin: auto;
        text-align: center;
        font-family: arial;
    }

    .title {
        color: grey;
        font-size: 18px;
    }

    button {
        border: none;
        outline: 0;
        display: inline-block;
        padding: 8px;
        color: black;
        background-color: #FFF;
        text-align: center;
        cursor: pointer;
        width: 100%;
        font-size: 18px;
    }

    a {
        text-decoration: none;
        font-size: 22px;
        color: black;
    }

    button:hover,
    a:hover {
        opacity: 0.7;
    }

    .scroll-bg {
        width: 400px;
        margin: 0px;
        padding: 400px;
        border-radius: 15px;
    }

    .scroll-div {
        width: 470px;
        height: 380px;
        overflow: hidden;
        overflow-y: scroll;

    }

    .scroll-object {
        color: black;
        font-family: cursive;
        font-size: 15px;
        padding: 20px;
    }
    </style>
</head>

<body>
    <header>
        <p style="color: white; "><img src="<?php echo $photo ;?>"
                style=" width: 40px; height: 40px; background: black; border-radius: 50%;"><br><?php echo $nom; ?></p>
        <div class="navigation">
            <ul class="menu">
                <div class="close-btn"></div>
                <br>
                <li class="menu-item"><a href="../moncompte/profil.php">Mon profil</a></li>
                <li class="menu-item">
                    <a class="sub-btn" href="#">Menu <i class="fas fa-angle-down"></i></a>
                    <ul class="sub-menu">
                        <li class="sub-item"><a href="../moncompte/ecrire.php">Publier une histoire</a></li>
                        <li class="sub-item"><a href="../moncompte/admin.php">Mes histoires</a></li>
                        <li class="sub-item"><a href="#"></a>#</li>
                    </ul>
                </li>

                <li class="menu-item"><a href="info.php">Mes infos</a></li>
                <li class="menu-item"><a href="logout.php">Déconnection</a></li>
            </ul>
        </div>
        <div class="menu-btn"></div>
    </header>
    <br>
    <br>
    <br>
    <br>
    <br>
    <img src="../images/rière.png" style="width:35px;"><a href="../moncompte/profil.php">Retour</a>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>


    <div class="container">
        <div class="row">
            <div class="col-5">
                <div class="fw-bold text-center">Titre: <?= $q -> titre?></div>
                <br>
                <div class="fw-bold text-center">Description: <?= $q->description?></div>
                <br>
                <div class="text-center"><?= $q-> date_pub?></div>
                <br>
                <div class="text-center"></div>
                <img src="<?= $q -> photo?>" alt="" class="card img rounded mx-auto">
            </div>
            <div class="col-7">
                <div class=" scroll-bg scroll-div scroll-object"><?= $q -> text_histoire?></div>
            </div>
        </div>
    </div>


</body>

</html>