<?php 
$idu = $row['idu'];
$checkutilisateur = "SELECT * FROM utilisateur WHERE id = '$idu'";
$resultutilisateur = mysqli_query($conn, $checkutilisateur);// execution requet check
$rowutilisateur = mysqli_fetch_assoc($resultutilisateur);// sauv information des champs de la table dans row
$publisherid = $rowutilisateur['id'];
 ?>