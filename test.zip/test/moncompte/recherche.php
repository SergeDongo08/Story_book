<?php
//Effectuer une recherche dans la base de données.
if(isset($_POST['submit'])){


    $str = mysqli_real_escape_string($conn,$_POST['str']);
    $sql = "SELECT id, titre, description,'histoire' FROM histoire WHERE titre 
    like '%$str%' or description like '%$str%'";
    $res=mysqli_query($conn,$sql);
    if ($res) {
       if(mysqli_num_rows($res)>0){
        while($row=mysqli_fetch_assoc($res)){
            echo "<div>
            <a href='lire.php?id=".$row['id']."'>".$row['titre']." <br></a>
            </div>";
            echo "<br/>";
            }
        }else{
            echo "Cette histoire n'est pas disponible. <br><br>";

            echo "<a href='profil.php'>Retour</a>";
        }
    }
        }else{

          $sql = "SELECT * FROM histoire ORDER BY id DESC";
          $result = mysqli_query($conn, $sql);

          if (mysqli_num_rows($result) > 0) {
            // output data of each row
            
            while ($row = mysqli_fetch_assoc($result)) { // boucle

         include 'hist.php';
          
              
            } //fin de la boucle
          } else {
            echo "Aucune histoire disponible.";
          }
           
        }
    

?>