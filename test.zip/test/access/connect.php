<?php
// Start the session
session_start();
?>
<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <title>Login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js" charset="utf-8"></script>
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap');

    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        text-decoration: none;
    }

    body {
        height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
        background: #F7B6A8;
        width: 100%;
    }

    .form {
        z-index: 1;
        font-family: "Poppins", sans-serif;
        position: absolute;
        width: 320px;
        text-align: center;
    }

    .form i {
        z-index: 1;
        color: #ccc;
        font-size: 65px;
        margin-bottom: 30px;
    }

    .form .signup-form {
        display: none;
    }

    .form .user-input {
        width: 320px;
        height: 55px;
        margin-bottom: 30px;
        outline: none;
        border: none;
        background: rgba(255, 255, 255, 0.2);
        color: #fff;
        font-size: 18px;
        text-align: center;
        border-radius: 5px;
        transition: 0.5s;
        transition-property: border-left, border-right, box-shadow;
    }

    .form .user-input:hover,
    .form .user-input:focus,
    .form .user-input:active {
        border-left: solid 8px #4285F4;
        border-right: solid 8px #4285F4;
        box-shadow: 0 0 100px rgba(66, 133, 244, 0.8);
    }

    .form .options-01 {
        margin-bottom: 50px;
    }

    .form .options-01 input {
        width: 15px;
        height: 15px;
        margin-right: 5px;
    }

    .form .options-01 .remember-me {
        color: #2E2C05;
        font-size: 14px;
        display: flex;
        align-items: center;
        float: left;
        cursor: pointer;
    }

    .form .options-01 a {
        color: #888;
        font-size: 14px;
        font-style: italic;
        float: right;
    }

    .form .btn {
        outline: none;
        border: none;
        width: 320px;
        height: 55px;
        background: #4285F4;
        color: #fff;
        font-size: 18px;
        letter-spacing: 1px;
        border-radius: 5px;
        cursor: pointer;
        transition: 0.5s;
        transition-property: border-left, border-right, box-shadow;
    }

    .form .btn:hover {
        border-left: solid 8px rgba(255, 255, 255, 0.5);
        border-right: solid 8px rgba(255, 255, 255, 0.5);
        box-shadow: 0 0 100px rgba(66, 133, 244, 0.8);
    }

    .form .options-02 {
        color: #2E2C05;
        font-size: 14px;
        margin-top: 30px;
    }

    .form .options-02 a {
        color: #4285F4;
    }

    /* Responsive CSS */

    @media screen and (max-width: 500px) {
        .form {
            width: 95%;
        }

        .form .user-input {
            width: 100%
        }

        .form .btn {
            width: 100%;
        }
    }
    </style>
</head>

<body>


    <!--form area start-->
    <div class="form">
        <!--login form start-->
        <form class="login-form" action="" method="post">
            <i class="fas fa-user-circle"></i>
            <input class="user-input" type="text" name="nom" placeholder="Nom d'utilisateur" required>
            <input class="user-input" type="password" name="passe" placeholder="Mot de passe" required>
            <div class="options-01">
                <label class="remember-me"><input type="checkbox" name="">Se souvenir de moi</label>
                <!--<a href="#">Mot de passe oublié?</a>-->
            </div>
            <input class="btn" type="submit" name="login" value="LOGIN">
            <div class="options-02">
                <p>Vous n'avez pas de compte? <a href="inscription.php">Créer un compte</a></p>
            </div>
            <div>
                <br>
                <br>
                <br>
                <br>
                <br>
                <br>
                <br>
                <img src="../images/rière.png" style="width:35px; "><a href="../index.php">Retour</a>
            </div>
        </form>

    </div>


    <script type="text/javascript">
    $('.options-02 a').click(function() {
        $('form').animate({
            height: "toggle",
            opacity: "toggle"
        }, "slow");
    });
    </script>
    <?php 
include 'connexion.php';
  //login
  if (isset($_POST['login'])) {
    $nom = addslashes($_POST['nom']);
    $password = md5(addslashes($_POST['passe']));

    //check user
    $check = "SELECT * FROM utilisateur WHERE nom ='$nom' AND passe = '$password' ";
    $result = mysqli_query($conn, $check);
    $nombre = mysqli_num_rows($result);
    //a = 2
    //si a = 0 display 5 sinon display 4

    if ($nombre == 1) {
      //aller à la page 
      $row = mysqli_fetch_assoc($result);
      $id = $row['id'];
     //Création de la session
    $_SESSION["id"] = $id;
 echo '<script>window.location.replace("../moncompte/profil.php")</script>';
  } else {
      //afficher message d'erreure
      echo "<br><br><br>mot de passe eronné";
    }
  }


  //fin login
  mysqli_close($conn);
  ?>
</body>

</html>