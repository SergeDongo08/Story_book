<?php 

try{
	$con = new PDO ('mysql: host=localhost;dbname=story_book', 'root', '');
	$con -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}catch(PDOexception $e){
	die('GBouyaye'. $e->getMessage());
}


?>