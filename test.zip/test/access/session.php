<?php
if(isset($_SESSION["id"])){
    $id_session_sauv = $_SESSION["id"];
    //Information utilisateur
    $check = "SELECT * FROM utilisateur WHERE id ='$id_session_sauv'";
    $result = mysqli_query($conn, $check);// execution requet check
    $nombre = mysqli_num_rows($result);// nombre de resultat
    $row = mysqli_fetch_assoc($result);// sauv information des champs de la table dans row
    $id = $row['id'];
    $nom = $row['nom'];
    $genre = $row['genre'];
    $habitation = $row['habitation'];
    $email = $row['email'];
    $passe = md5($row['passe']);
    $photo = $row['photo'];
    $time = date("h:i:sa"); 
    $date_pub = date("Y-m-d h:i:sa");


}
?>