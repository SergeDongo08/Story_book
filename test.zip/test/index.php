<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>MY STORY BOOK</title>
    <style>
      @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap');
@import url('https://fonts.googleapis.com/css2?family=Kaushan+Script&display=swap');

*{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: "Poppins", sans-serif;
  scroll-behavior: smooth;
}

body{
  min-height: 100vh;
  overflow-x: hidden;
}

header{
  z-index: 999;
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  padding: 30px 100px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

header .logo{
  font-size: 2em;
  text-transform: uppercase;
  font-weight: 800;
  text-decoration: none;
  background: linear-gradient(to right, #d7487e, #ea6360);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}

header nav{
  display: flex;
  justify-content: center;
  align-items: center;
}

header nav a{
  color: #d9497e;
  font-size: 1.1em;
  font-weight: 500;
  text-decoration: none;
  margin-left: 20px;
  padding: 5px 16px;
  border-radius: 20px;
  transition: 0.3s;
  transition-property: background, color;
}

header nav a:hover{
  background: linear-gradient(to bottom, #d94a7f, #fe9261);
  color: #fff;
}

.home{
  position: relative;
  width: 100%;
  height: 100vh;
  padding: 100px;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
}

.info{
  z-index: 8;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  transform: translateY(200px);
  opacity: 0;
  transition: 0.6s;
}

.info .title{
  font-family: 'Kaushan Script', cursive;
  font-size: 9em;
  background: linear-gradient(to right, #d7487e, #ea6360);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  width: 360px;
  height: 215px;
  margin-bottom: 30px;
}

.info .paragraph{
  color: #19628b;
  font-size: 1.2em;
  width: 50%;
  margin-bottom: 40px;
}

.info .btn{
  font-size: 1.3em;
  font-weight: 500;
  text-decoration: none;
  background: linear-gradient(to bottom, #d94a7f, #fe9261);
  color: #fff;
  padding: 10px 35px;
  border-radius: 5px;
  transition: 0.3s;
}

.info .btn:hover{
  transform: scale(1.05);
}

.home img{
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
  pointer-events: none;
}

.content{
  z-index: 10;
  position: relative;
  padding: 90px 100px;
  background: #722d59;
}

.content h2{
  color: #fff;
  font-size: 3em;
  font-weight: 700;
  margin-bottom: 10px;
}

.content p{
  color: #fff;
  font-size: 1em;
}
  
    </style>
  </head>
  <body>

    <header>
      <a href="#" class="logo"><img src="ic.png" style="width:3%;"></a>
      <nav>
        <a href="#">Accueil</a>
        <a href="access/connect.php">Connectez-vous</a>
        <a href="#">A propos</a>
        <!--<a href="#">More</a>-->
      </nav>
    </header>
    <section class="home">
      <img src="bg.png" alt="">
      <img src="pyramids.png" class="pyramids" alt="">
      <img src="lg.png" class="palace" alt="">
      <div class="info">
        <h2 class="title">MSB</h2>
        <p class="paragraph">"My Story Book" est une plateforme d'échange, où toute personne peut publier une histoire afin de partager ses émotions et son expérience avec les autres
        lecteurs.</p>
        <a href="access/connect.php" class="btn">COMMMENCEZ!!</a>
      </div>
    </section>

    
        <script type="text/javascript">
    const pyramids = document.querySelector(".pyramids");
    const palace = document.querySelector(".palace");
    const logo = document.querySelector(".logo");
    const nav = document.querySelector("nav");
    const info = document.querySelector(".info");

    //reveal elements on page loading
    window.addEventListener("load", () => {
      pyramids.style.transform = "translateX(0)";
      palace.style.transform = "translateX(0)";
      logo.style.transform = "translateY(0)";
      nav.style.transform = "translateY(0)";

      setTimeout(() => {
        info.style.transform = "translateY(0)";
        info.style.opacity = "1";
      }, 500);
    });//

    </script>
      
  </body>
</html>
      